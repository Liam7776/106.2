﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Security.Policy;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Media;

namespace Library_App
{
    public partial class Window1 : Window
    {
        public string CurrentUser;
        public string Admin;
        public int Overdues; //Counts he number of overdue books for each user
        // List to store book objects
        private List<BookDetails> booksList = new List<BookDetails>();

        //public Window1(string userName, char admin)
        public Window1(string userName, string admin)
        {
            InitializeComponent();

            CurrentUser = userName;
            Admin = admin;

            // Make the admin button visible only if the user is an admin
            if (Admin == "Y")
            {
                AdminControls.Visibility = Visibility.Visible;
            }
            else
            {
                AdminControls.Visibility = Visibility.Collapsed;
            }

            UserOptionLabel.Content = CurrentUser;

            booksList.Clear();
            GetBooks();

        }

        //When the user chooses to log out
        private void LogOutButton(object sender, RoutedEventArgs e)
        {
            MainWindow Main = new MainWindow();
            Main.Show();
            this.Close();
        }

        //Sets up all the books
        private void GetBooks()
        {
            string filePath = @"C:\Users\270197547\OneDrive - UP Education\Documents\2024 programming\106.2 main assesment\MainWebsite\Library App\Library App\Books.csv";
            //string filePath = @"C:\2024 Yoobee work\Term 4 home\106 home\MainWebsite\Library App\Library App\Books.csv";

            try
            {
                var lines = File.ReadAllLines(filePath);

                // Loop through each line in the CSV file (skipping the header)
                foreach (var line in lines.Skip(1))
                {
                    var values = line.Split(',');

                    if (values.Length >= 11) // Ensure all fields are present
                    {
                        //Calls the book class and sets up an object for each book
                        var book = new BookDetails(
                            values[0].Trim(), values[1].Trim(), values[2].Trim(),
                            values[3].Trim(), values[4].Trim(), values[5].Trim(),
                            values[6].Trim(), values[7].Trim(), values[8].Trim(),
                            values[9].Trim(), values[10].Trim()
                        );

                        // Add each book object to the list
                        booksList.Add(book);

                        Color Backgroundcolor = (Color)ColorConverter.ConvertFromString("#FFDFD991"); //Sets up background color for the buttons/books
                        // Create a StackPanel for each book and add it as a button
                        Button bookButton = new Button { Margin = new Thickness(5), Width = 250, Height = 380 }; //Need to set the color right
                        StackPanel bookPanel = new StackPanel { Orientation = Orientation.Vertical };
                        // Load and display book cover image
                        Image bookImage = new Image { Width = 200, Height = 250, Margin = new Thickness(0, 0, 0, 5) };
                        BitmapImage bitmap = new BitmapImage();
                        bitmap.BeginInit();
                        bitmap.UriSource = new Uri(book.ImageLink, UriKind.Absolute);
                        bitmap.EndInit();
                        bookImage.Source = bitmap;

                        // Add book information to display
                        TextBlock titleBlock = new TextBlock { Text = "Title: " + book.Title, FontWeight = FontWeights.Bold };
                        TextBlock authorBlock = new TextBlock { Text = "Author: " + book.Author };
                        TextBlock dateBlock = new TextBlock { Text = "Published Date: " + book.PublishedDate };

                        // Add details to the StackPanel
                        bookPanel.Children.Add(bookImage);
                        bookPanel.Children.Add(titleBlock);
                        bookPanel.Children.Add(authorBlock);
                        bookPanel.Children.Add(dateBlock);

                        //Checks weather or not the book is availbile
                        if (book.Status == "1")
                        {
                            //Checks to see if the book is pre-booked or not:
                            string StatusOfBook = "";
                            StatusOfBook = PreBookingCheck(book.Title);

                            //TextBlock Availibility = new TextBlock { Text = "Availible", FontWeight = FontWeights.Bold };
                            TextBlock Availibility = new TextBlock { Text = StatusOfBook, FontWeight = FontWeights.Bold };
                            bookPanel.Children.Add(Availibility);
                        }

                        else if (book.Status == "0" && book.CurrentOwner == CurrentUser)
                        {
                            string BookName = book.Title;
                            string DueDate = book.ReturnDate;
                            //Checks to see weather this book is overdue or what the due date is
                            string OwnershipStatus = OverDueCheck(BookName, DueDate);
                            //string OwnershipStatus = "You own: Due date: " + book.ReturnDate;
                            TextBlock Availibility = new TextBlock { Text = OwnershipStatus, FontWeight = FontWeights.Bold };
                            bookPanel.Children.Add(Availibility);
                        }

                        else if (book.Status == "0" && book.CurrentOwner != CurrentUser)
                        {
                            TextBlock Availibility = new TextBlock { Text = "Unavailible: Rented by: " + book.CurrentOwner, FontWeight = FontWeights.Bold };
                            bookPanel.Children.Add(Availibility);
                        }

                        // Set the StackPanel as the content of the button
                        bookButton.Content = bookPanel;

                        // Set button click event to open Window8
                        bookButton.Click += (sender, e) => ViewBook(book);

                        // Add the button to the main BooksPanel
                        BooksPanel.Children.Add(bookButton);
                    }
                    else
                    {
                        MessageBox.Show("Unexpected line format in CSV file: " + line, "Format Error");
                    }
                }
            }
            catch (FileNotFoundException)
            {
                MessageBox.Show("Books file not found. Please check the file path.", "File Not Found", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error reading the books file: " + ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }

            if (Overdues > 0) //Tells the user to return any books if they have any over dues
            {
                MessageBox.Show("Please return overdue books before you can rent anymore", "Books past due");
            }
        }

        //Takes the user to the page where they can rent and return books
        private void ViewBook(BookDetails book)
        {
            // Pass the book details to Window8
            Window8 window8 = new Window8(book, CurrentUser, Admin, Overdues);

            // Show Window8
            window8.Show();
            this.Close();
        }

        private void AdminOptions(object sender, RoutedEventArgs e)
        {
            //Create an instance of window3
            AdminOptions ADO = new AdminOptions(CurrentUser, Admin);

            //Show window3
            ADO.Show();

            //Close the main window (optional)
            this.Close();
        }

        //Checks to see if the book is overdue or not
        private string OverDueCheck(string bookName, string dueDateStr)
        {
            DateTime dueDate;
            DateTime currentDate = DateTime.Now;

            // Try parsing the due date from the string format
            if (DateTime.TryParse(dueDateStr, out dueDate))
            {
                TimeSpan difference = dueDate - currentDate.Date; // Compare dates only

                // If the book is overdue
                if (difference.TotalDays <= 0)
                {
                    string logPath = @"C:\Users\270197547\OneDrive - UP Education\Documents\2024 programming\106.2 main assesment\MainWebsite\Library App\Library App\Message log\OverdueLog.csv";
                    //string logPath = @"C:\2024 Yoobee work\Term 4 home\106 home\MainWebsite\Library App\Library App\Message log\OverdueLog.csv";
                    MessageBox.Show("The book: " + bookName + " is overdue", "Books past due");
                    Overdues++;

                    // Ensure the log file exists with a header
                    if (!File.Exists(logPath))
                    {
                        using (var writer = new StreamWriter(logPath, append: true))
                        {
                            writer.WriteLine("User,Status,Book Name,DueDate");
                        }
                    }

                    // Appends the overdue book information to the overdue log
                    using (var writer = new StreamWriter(logPath, append: true))
                    {
                        writer.WriteLine($"User: {CurrentUser}:,has an overdue book:,Book name: {bookName}, DueDate: {dueDateStr}");
                    }

                    return "You owe: Overdue";
                }
                
                //If a book is due soon
                else if (difference.TotalDays == 1)
                {
                    // If the book is due tomorrow
                    string logPath = @"C:\Users\270197547\OneDrive - UP Education\Documents\2024 programming\106.2 main assesment\MainWebsite\Library App\Library App\Message log\DueDatelog.csv";
                    //string logPath = @"C:\2024 Yoobee work\Term 4 home\106 home\MainWebsite\Library App\Library App\Message log\DueDatelog.csv";
                    MessageBox.Show("The book: " + bookName + " is due back tomorrow", "Due date reminder");

                    // Ensure the log file exists with a header
                    if (!File.Exists(logPath))
                    {
                        using (var writer = new StreamWriter(logPath, append: true))
                        {
                            writer.WriteLine("User,Status,Book Name,DueDate");
                        }
                    }

                    // Append overdue information
                    using (var writer = new StreamWriter(logPath, append: true))
                    {
                        writer.WriteLine($"User: {CurrentUser}:,has a book due tomorrow:,Book name: {bookName}, DueDate: {dueDateStr}");
                    }
                    return "You owe: Due tomorrow";

                }
                else
                {
                    // If the book is not overdue or due tomorrow
                    return "You owe: Due date " + dueDate.ToString("MM/dd/yyyy");
                }
            }
            else
            {
                // Handle parsing error
                return "Date error: Invalid date format";
            }

        }

        //Checks if see if the book is not only pre-orered but also if the user is next for it
        private string PreBookingCheck(string BooksName)
        {
            string PreOrderFilePath = @"C:\Users\270197547\OneDrive - UP Education\Documents\2024 programming\106.2 main assesment\MainWebsite\Library App\Library App\PreOrderList.csv";
            //string PreOrderFilePath = @"C:\2024 Yoobee work\Term 4 home\106 home\MainWebsite\Library App\Library App\PreOrderList.csv";
            try
            {
                var POlines = File.ReadAllLines(PreOrderFilePath);
                for (int i = 1; i < POlines.Length; i++)
                {
                    var POvalues = POlines[i].Split(',');

                    // Check if this line corresponds to the current book
                    if (POvalues[0].Trim() == BooksName)
                    {
                        if (string.IsNullOrWhiteSpace(POvalues[1]))
                        {
                            return "Availbile";
                        }

                        else if (POvalues[1].Trim() == CurrentUser)
                        {
                            return "Availbile";
                        }

                        else 
                        {
                            return "Unavailible: Pre-booked";
                        }

                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error updating CSV file: " + ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return "Availiblity error";
            }

            return "Availible";
        }

        //Used when the user wishes to log out
        private void LogOut_Click(object sender, RoutedEventArgs e)
        {
            //Create an instance of the main/log in screen
            MainWindow Main = new MainWindow();

            //Show the main window
            Main.Show();

            //Close the homepage
            this.Close();
        }
    }
}