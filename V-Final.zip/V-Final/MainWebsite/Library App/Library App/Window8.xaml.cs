﻿using System;
using System.Collections.ObjectModel;
using System.Globalization;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Runtime.InteropServices;
using System.ComponentModel;

namespace Library_App
{
    /// <summary>
    /// Interaction logic for Window7.xaml
    /// </summary>
    public partial class Window8 : Window
    {
        public string CurrentUser;
        public string Admin;
        private bool canRent = true;
        private bool OverDuecheck = false;
        private int OverDues;

        //Variables used to store/get the books data
        private string Booktitle;
        private string BookAuthor;
        private string PublishedDate;
        private string PageNumber;
        private string StoryDesc;
        private string Review;
        private string GenreCode;
        private string ListedGenres;
        private string CurrentStatus;
        private string CurrentOwner;
        private string ReturnDate;
        private string Image;
        private int OverDueCount;


        //public Window8(string name, string author, string date, string Pages, string desc, string review, string GCode, string status, string Owner, string ReturnDate, string image)
        public Window8(BookDetails BookInfo, string userName, string admin, int OD) //OD stands for overdues
        {
            InitializeComponent();
            //Sets up all the vriables
            this.Booktitle = BookInfo.Title;
            this.BookAuthor = BookInfo.Author;
            this.PublishedDate = BookInfo.PublishedDate;
            this.PageNumber = BookInfo.PageNum;
            this.StoryDesc = BookInfo.Desc;
            this.Review = BookInfo.ReviewScore;
            this.GenreCode = BookInfo.GenreCode;
            this.CurrentStatus = BookInfo.Status;
            this.CurrentOwner = BookInfo.CurrentOwner;
            this.ReturnDate = BookInfo.ReturnDate;
            this.Image = BookInfo.ImageLink;
            this.OverDueCount = OD;

            CurrentUser = userName;
            Admin = admin;
            OverDues = OD;

            UserOptionLabel.Content = CurrentUser;

            checkButtons(); //Called and used to set what buttons are shown
            DisplayInfo();
        }

        //Checks the availiblity and current owner of the book to determine what button/text to display
        private void checkButtons()
        {
            string preOrderFilePath = @"C:\Users\270197547\OneDrive - UP Education\Documents\2024 programming\106.2 main assesment\MainWebsite\Library App\Library App\PreOrderList.csv";
            //string preOrderFilePath = @"C:\2024 Yoobee work\Term 4 home\106 home\MainWebsite\Library App\Library App\PreOrderList.csv";

            if (OverDues > 0) //If the user has any overdue books
            {
                OverDueBox.Visibility = Visibility.Visible;
                DateCheck(ReturnDate);
                if (CurrentStatus == "1")
                {
                    ReturnBookButton.Visibility = Visibility.Collapsed;
                    RentBookButton.Visibility = Visibility.Collapsed;
                    PreOrderButton.Visibility = Visibility.Collapsed;
                    TextBlock StatusBlock = new TextBlock { Text = "Please return overdue books"};
                    CurrentStatusData.Content = StatusBlock;
                }

                else if (CurrentStatus == "0" && CurrentUser == CurrentOwner)
                {
                    ReturnBookButton.Visibility = Visibility.Visible;
                    RentBookButton.Visibility = Visibility.Collapsed;
                    PreOrderButton.Visibility = Visibility.Collapsed;
                    string DateSate = DateComparison(ReturnDate);

                    TextBlock StatusBlock = new TextBlock { Text = DateSate };
                    CurrentStatusData.Content = StatusBlock;
                }

                else if (CurrentStatus == "0" && CurrentUser != CurrentOwner)
                {
                    ReturnBookButton.Visibility = Visibility.Collapsed;
                    RentBookButton.Visibility = Visibility.Collapsed;
                    PreOrderButton.Visibility = Visibility.Collapsed;
                    TextBlock StatusBlock = new TextBlock { Text = "Please return overdue books" };
                    CurrentStatusData.Content = StatusBlock;
                }
            }

            // If the user has no overdue books
            else if (OverDues < 1)
            {
                OverDueBox.Visibility = Visibility.Collapsed;
                if (CurrentStatus == "1")
                {
                    // Check for pre-orders in the first column ("User 1")
                    if (File.Exists(preOrderFilePath))
                    {
                        var lines = File.ReadAllLines(preOrderFilePath).Skip(1); // Skip header
                        foreach (var line in lines)
                        {
                            var values = line.Split(',');

                            // Find the matching book title
                            if (values[0].Trim() == Booktitle && values.Length > 1 && !string.IsNullOrWhiteSpace(values[1]))
                            {
                                // If "User 1" exists, set canRent to true only for that user
                                canRent = (values[1].Trim() == CurrentUser);
                                break;
                            }
                        }
                    }

                    // Show buttons based on whether the current user can rent
                    RentBookButton.Visibility = canRent ? Visibility.Visible : Visibility.Collapsed;
                    PreOrderButton.Visibility = canRent ? Visibility.Collapsed : Visibility.Visible;

                    TextBlock StatusBlock = new TextBlock { Text = canRent ? "Available for you" : "Available for pre-order" };
                    CurrentStatusData.Content = StatusBlock;
                }

                //If the user currently owns the book
                else if (CurrentStatus == "0" && CurrentUser == CurrentOwner)
                {
                    ReturnBookButton.Visibility = Visibility.Visible;
                    RentBookButton.Visibility = Visibility.Collapsed;
                    PreOrderButton.Visibility = Visibility.Collapsed;

                    string DateSate = DateComparison(ReturnDate);

                    TextBlock StatusBlock = new TextBlock { Text = DateSate };
                    CurrentStatusData.Content = StatusBlock;
                }

                //The book is rented by someone else
                else if (CurrentStatus == "0" && CurrentUser != CurrentOwner)
                {
                    ReturnBookButton.Visibility = Visibility.Collapsed;
                    RentBookButton.Visibility = Visibility.Collapsed;
                    PreOrderButton.Visibility = Visibility.Visible;

                    TextBlock StatusBlock = new TextBlock { Text = "Currently rented by: " + CurrentOwner };
                    CurrentStatusData.Content = StatusBlock;

                    if (OverDues > 0)
                    {

                        PreOrderButton.Visibility = Visibility.Collapsed;
                        OverDueBox.Visibility = Visibility.Visible;
                    }
                }
            }
        }

        private void DisplayInfo()
        {
            Image BookImage = new Image { Width = 200, Height = 250, Margin = new Thickness(0, 0, 0, 5) };
            BitmapImage bitmap = new BitmapImage();
            bitmap.BeginInit();
            bitmap.UriSource = new Uri(Image, UriKind.Absolute);
            bitmap.EndInit();

            BooksCover.Source = bitmap;

            //Sets up and displays the information on the book
            TextBlock titleBlock = new TextBlock { Text = Booktitle, FontWeight = FontWeights.Bold };
            TextBlock authorBlock = new TextBlock { Text = "Author: " + BookAuthor };
            TextBlock dateBlock = new TextBlock { Text = "Published Date: " + PublishedDate };
            TextBlock pageBlock = new TextBlock { Text = "Pages: " + PageNumber };
            TextBlock descriptionBlock = new TextBlock { Text = "Description: " + StoryDesc};
            TextBlock ReviewBlock = new TextBlock { Text = Review + "/5" };


            //Setting up the genres
            ListedGenres = SetGenres();

            //Setting up the genres for the book

            BooksTitle.Content = titleBlock;
            BooksAuthor.Content = authorBlock;
            BooksPublishedDate.Content = dateBlock;
            NumberOfPages.Content = pageBlock;
            ReviewScore.Content = ReviewBlock;
            //StoryDescBox.Content = descriptionBlock;
            StoryDescBox.Text = "Description: " + StoryDesc;
            GenreLabel.Content = ListedGenres;

        }

        // Dictionary to map single character genre codes to genre descriptions

        private Dictionary<char, string> genreDescriptions = new Dictionary<char, string>
        {
            { 'A', "Action and Adventure" },
            { 'B', "Biography" },
            { 'C', "Comedy" },
            { 'D', "Drama" },
            { 'E', "Children Books" },
            { 'F', "Fantasy" },
            { 'G', "Graphic Novel/Comic" },
            { 'H', "Horror" },
            { 'I', "Sci-fi" },
            { 'J', "Romance" },
            { 'K', "War" },
            { 'L', "Thriller" },
            { 'M', "Mystery" },
            { 'N', "Non-fiction" },
            { 'O', "Other" }
        };


        //The function sets up the genre string
        private string SetGenres()
        {
            // Process and display genres based on GenreCode
            ListedGenres = "Genres: ";
            foreach (char code in GenreCode)
            {
                if (genreDescriptions.ContainsKey(code))
                {
                    ListedGenres += genreDescriptions[code] + ", ";
                }
                else
                {
                    ListedGenres += "Unknown Genre, ";
                }
            }

            // Trim the trailing comma and space
            ListedGenres = ListedGenres.TrimEnd(',', ' ');

            return ListedGenres;
        }


        //Button for when the user returns a book
        private void RentButton_Click(object sender, RoutedEventArgs e)
        {
            if (CurrentStatus == "1" && canRent)
            {
                MessageBox.Show("Book Rented", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                CurrentStatus = "0";
                CurrentOwner = CurrentUser;

                // Determine return date based on user type
                ReturnDate = (Admin == "Y") ? DateTime.Now.AddDays(21).ToString("d") : DateTime.Now.AddDays(14).ToString("d");

                UpdateCsvFile();
                RemoveAndShiftPreOrders();
            }
            else
            {
                MessageBox.Show("This book is already rented by another user or you are not next in line for rental.", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        //Updates the pre order list when a book someone pre-ordered is rented
        private void RemoveAndShiftPreOrders()
        {
            string preOrderFilePath = @"C:\Users\270197547\OneDrive - UP Education\Documents\2024 programming\106.2 main assesment\MainWebsite\Library App\Library App\PreOrderList.csv";
            //string preOrderFilePath = @"C:\2024 Yoobee work\Term 4 home\106 home\MainWebsite\Library App\Library App\PreOrderList.csv";

            // Read all lines from PreOrderList.csv
            var lines = File.ReadAllLines(preOrderFilePath).ToList();

            for (int i = 1; i < lines.Count; i++) // Start from 1 to skip header
            {
                var values = lines[i].Split(',');

                // Find the matching book title
                if (values[0].Trim() == Booktitle)
                {
                    // Shift users to the left, starting from "User 2"
                    for (int j = 1; j < values.Length - 1; j++)
                    {
                        values[j] = values[j + 1];
                    }
                    // Clear the last user column
                    values[values.Length - 1] = "";

                    // Update the line with shifted user names
                    lines[i] = string.Join(",", values);
                    break;
                }
            }

            // Write updated lines back to PreOrderList.csv
            File.WriteAllLines(preOrderFilePath, lines);
        }

        //When the user is returning a book they rented
        private void ReturnButton_Click(object sender, RoutedEventArgs e)
        {
            if (CurrentStatus == "0" && CurrentOwner == CurrentUser)
            {
                MessageBox.Show("Book Returned", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                CurrentStatus = "1";
                CurrentOwner = "none";
                ReturnDate = "none";
                DateTime DateReturned = DateTime.Now;
                string DateBookReturned = "On the " + DateReturned;

                //Logs that the book was returned an on what day
                string LogPath = @"C:\Users\270197547\OneDrive - UP Education\Documents\2024 programming\106.2 main assesment\MainWebsite\Library App\Library App\Message log\ReturnLog.csv";
                //string LogPath = @"C:\2024 Yoobee work\Term 4 home\106 home\MainWebsite\Library App\Library App\Message log\ReturnLog.csv";
                if (!File.Exists(LogPath))
                {
                    using (var writer = new StreamWriter(LogPath, append: true))
                    {
                        writer.WriteLine("User,Action,BookName,Date");
                    }
                }

                using (var writer = new StreamWriter(LogPath, append: true))
                {
                    writer.WriteLine($"User: {CurrentUser}:,Returned the book:,{Booktitle},{DateBookReturned}");
                }

                if (OverDuecheck == true)
                {
                    OverDuecheck = false;
                    OverDues--;
                }

                UpdateCsvFile();
            }
            else
            {
                MessageBox.Show("You cannot return a book you haven't rented.", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        //The user chooses the pre-order the book
        private void PreOrderButton_Click(object sender, RoutedEventArgs e)
        {
            string preOrderFilePath = @"C:\Users\270197547\OneDrive - UP Education\Documents\2024 programming\106.2 main assesment\MainWebsite\Library App\Library App\PreOrderList.csv";
            //string preOrderFilePath = @"C:\2024 Yoobee work\Term 4 home\106 home\MainWebsite\Library App\Library App\PreOrderList.csv";
            string logPath = @"C:\Users\270197547\OneDrive - UP Education\Documents\2024 programming\106.2 main assesment\MainWebsite\Library App\Library App\Message log\PreOrderLog.csv";
            //string LogPath = @"C:\2024 Yoobee work\Term 4 home\106 home\MainWebsite\Library App\Library App\Message log\PreOrderLog.csv";

            // Log the pre-order action
            DateTime preOrderedDate = DateTime.Now;
            if (!File.Exists(logPath))
            {
                using (var writer = new StreamWriter(logPath, append: true))
                {
                    writer.WriteLine("User,Action,BookName,Date");
                }
            }
            using (var writer = new StreamWriter(logPath, append: true))
            {
                writer.WriteLine($"User: {CurrentUser},Pre-ordered the book,{Booktitle},On {preOrderedDate}");
            }

            // Ensure PreOrderList.csv exists, create it if it does not
            if (!File.Exists(preOrderFilePath))
            {
                using (var writer = new StreamWriter(preOrderFilePath, append: true))
                {
                    writer.WriteLine("Book Name,User 1"); // Initial header with one user column
                }
            }

            // Read all lines from PreOrderList.csv
            var lines = File.ReadAllLines(preOrderFilePath).ToList();
            bool bookFound = false;

            // Iterate through lines to find the book
            for (int i = 1; i < lines.Count; i++) // Start from 1 to skip header
            {
                var values = lines[i].Split(',');

                // Check if the book title matches
                if (values[0].Trim() == Booktitle)
                {
                    bookFound = true;

                    // Check if the user already exists in any of the columns
                    bool userExists = values.Skip(1).Any(v => v.Trim() == CurrentUser);
                    if (!userExists)
                    {
                        // Ensure the row has enough columns for the new user
                        while (values.Length < lines[0].Split(',').Length)
                        {
                            values = values.Append("").ToArray(); // Add empty column placeholders
                        }

                        // Add the current user to the first available empty column
                        for (int j = 1; j < values.Length; j++)
                        {
                            if (string.IsNullOrWhiteSpace(values[j]))
                            {
                                values[j] = CurrentUser;
                                break;
                            }
                        }

                        // Update the row in the list
                        lines[i] = string.Join(",", values);
                    }
                    else
                    {
                        MessageBox.Show("You have already pre-ordered this book.", "Info", MessageBoxButton.OK, MessageBoxImage.Information);
                        return;
                    }
                    break;
                }
            }

            // If the book title was not found, add a new entry for it with the current user's name
            if (!bookFound)
            {
                lines.Add($"{Booktitle},{CurrentUser}");

                // Ensure the header has enough columns
                while (lines[0].Split(',').Length < lines.Last().Split(',').Length)
                {
                    lines[0] += $",User {lines[0].Split(',').Length}";
                }
            }

            // Write all lines back to PreOrderList.csv
            File.WriteAllLines(preOrderFilePath, lines);
            MessageBox.Show("Book pre-ordered successfully!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
        }


        //Updates the books csv to change the data based on weather or not the book was rented or returned
        private void UpdateCsvFile()
        {
            string filePath = @"C:\Users\270197547\OneDrive - UP Education\Documents\2024 programming\106.2 main assesment\MainWebsite\Library App\Library App\Books.csv";
            //string filePath = @"C:\2024 Yoobee work\Term 4 home\106 home\MainWebsite\Library App\Library App\Books.csv";
            try
            {
                var lines = File.ReadAllLines(filePath);
                for (int i = 1; i < lines.Length; i++)
                {
                    var values = lines[i].Split(',');

                    // Check if this line corresponds to the current book
                    if (values[0].Trim() == Booktitle && values[1].Trim() == BookAuthor)
                    {
                        // Update values for current status, owner, and return date
                        values[7] = CurrentStatus;
                        values[8] = CurrentOwner;
                        values[9] = ReturnDate;

                        // Update the line in the array
                        lines[i] = string.Join(",", values);
                        checkButtons();
                        break;
                    }
                }

                // Write all lines back to the CSV file
                File.WriteAllLines(filePath, lines);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error updating CSV file: " + ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        //When the user wishes to just return to the homepage
        private void ReturnHome_Click(object sender, RoutedEventArgs e)
        {
            //Create an instance of window3
            Window1 window1 = new Window1(CurrentUser, Admin);

            //Show window3
            window1.Show();

            //Close the main window (optional)
            this.Close();
        }
        

        //Checks to see if the user owns this book or not
        private void DateCheck(string dueDateStr)
        {
            DateTime dueDate;
            DateTime currentDate = DateTime.Now;

            if (DateTime.TryParse(dueDateStr, out dueDate))
            {
                if (currentDate >= dueDate)
                {
                    OverDuecheck = true;
                }
            }
        }
        
        private string DateComparison(string dueDateStr)
        {
            DateTime dueDate;
            DateTime currentDate = DateTime.Now;


            // Try parsing the due date from the string format
            if (DateTime.TryParse(dueDateStr, out dueDate))
            {

                TimeSpan difference = dueDate - currentDate.Date; // Compare dates only
                // If the book is overdue
                if (currentDate >= dueDate)
                {
                    return "You own: Overdue";

                }

                //If the book is due tomorrow
               else if (difference.TotalDays == 1)
                {
                    return "You own: Due tomorrow";
                }

                else
                {
                    return "You own: Due date " + dueDate.ToString("MM/dd/yyyy");
                }
            }

            else
            {
                // Handle parsing error
                return "Date error: Invalid date format";
            }
        }

        //When the user chooses to log out
        private void LogOut_Click(object sender, RoutedEventArgs e)
        {
            //Create an instance of the main/log in screen
            MainWindow Main = new MainWindow();

            //Show the main window
            Main.Show();

            //Close the homepage
            this.Close();
        }
    }
}
