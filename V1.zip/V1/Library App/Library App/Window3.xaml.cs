﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Library_App
{
    public partial class Window3 : Window
    {
        public Window3()
        {
            InitializeComponent();
        }


        private void NextButton_Click(object sender, RoutedEventArgs e)
        {
            // Capture data from TextBoxes
            string bookName = BookNameTextBox.Text;
            bookName = bookName.ToLower();
            string authorName = AuthorNameTextBox.Text;
            authorName = authorName.ToLower();
            string publishedDate = $"{DayTextBox.Text}/{MonthTextBox.Text}/{YearTextBox.Text}";
            string numberOfPages = PagesTextBox.Text;
            string description = DescriptionTextBox.Text;
            string review = ReviewTextBox.Text;

            // Define the CSV file path
            string filePath = @"C:\Users\270197547\OneDrive - UP Education\Documents\2024 programming\106.2 main assesment\MainWebsite\Books.csv";

            // Check if file exists; if not, create it and add headers
            if (!File.Exists(filePath))
            {
                using (var writer = new StreamWriter(filePath, append: true))
                {
                    writer.WriteLine("Book Name,Author Name,Published Date,Number of Pages,Description,Review");
                }
            }

            // Append the book details to the CSV file
            using (var writer = new StreamWriter(filePath, append: true))
            {
                writer.WriteLine($"{bookName},{authorName},{publishedDate},{numberOfPages},{description},{review}");
            }

            // Clear input fields after saving
            BookNameTextBox.Clear();
            AuthorNameTextBox.Clear();
            DayTextBox.Clear();
            MonthTextBox.Clear();
            YearTextBox.Clear();
            PagesTextBox.Clear();
            DescriptionTextBox.Clear();
            ReviewTextBox.Clear();

            // Notify the user
            MessageBox.Show("Book details saved successfully!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void DescriptionTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}