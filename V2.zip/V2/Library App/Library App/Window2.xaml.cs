﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static System.Net.Mime.MediaTypeNames;

namespace Library_App
{
    /// <summary>
    /// Interaction logic for Window2.xaml
    /// </summary>
    public partial class Window2 : Window
    {
        public Window2()
        {
            InitializeComponent();
        }

        private void SignUpButton_Click(object sender, RoutedEventArgs e)
        {
            //Capturing data from textboxes
            string UserName = EnterUserName.Text;
            string Password = EnterPassword.Text;
            string DateOfBirth = $"{DayTextBox.Text}/{MonthTextBox.Text}/{YearTextBox.Text}";
            string PhoneNum = EnterPhoneNumber.Text;

            bool Create = true;
            //Checks to ensure that the entered data is correct
            if (UserName.Length == 0 || Password.Length == 0 || DateOfBirth.Length != 10 || PhoneNum.Length == 0)
            {
                MessageBox.Show("Please enter all the requested data correctly", "Failed", MessageBoxButton.OK, MessageBoxImage.Information);
                Create = false;
            }

            if (Create == true)
            {

            }
            string filePath = @"C:\Users\270197547\OneDrive - UP Education\Documents\2024 programming\106.2 main assesment\MainWebsite\Accounts.csv";

            // Check if file exists; if not, create it and add headers
            if (!File.Exists(filePath))
            {
                using (var writer = new StreamWriter(filePath, append: true))
                {
                    writer.WriteLine("Username,Password,Date of Birth,Phone Number");
                }
            }

            // Append the book details to the CSV file
            using (var writer = new StreamWriter(filePath, append: true))
            {
                writer.WriteLine($"{UserName},{Password},{DateOfBirth},{PhoneNum}");
            }
        }

        private void EnterPhoneNumber_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}