﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Library_App
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window4 : Window
    {
        private string title;
        private string author;
        private string PDate;
        private string numberOfPages;
        private string description;
        private string review;
        public Window4(string title, string author, string PDate, string pageNum, string Description, string score)
        {
            InitializeComponent();

            // Initialize the fields
            this.title = title;
            this.author = author;
            this.PDate = PDate;
            this.numberOfPages = pageNum;
            this.description = Description;
            this.review = score;

        }

        //When the user is ready to add a new book, the code checks what genres have been checked (if any) and then stores all the data
        private void AddToCattalogue_Click(object sender, RoutedEventArgs e)
        {
            string genreCode = "";
            int Genres = 0;

            //Checking what boxes are/aren't ticked
            if (CheckA.IsChecked == true)
            {
                genreCode = genreCode + "A";
                Genres ++;
            }

            if (CheckB.IsChecked == true)
            {
                genreCode = genreCode + "B";
                Genres++;
            }

            if (CheckC.IsChecked == true)
            {
                genreCode = genreCode + "C";
                Genres++;
            }

            if (CheckD.IsChecked == true)
            {
                genreCode = genreCode + "D";
                Genres++;
            }

            if (CheckE.IsChecked == true)
            {
                genreCode = genreCode + "E";
                Genres++;
            }

            if (CheckF.IsChecked == true)
            {
                genreCode = genreCode + "F";
                Genres++;
            }

            if (CheckG.IsChecked == true)
            {
                genreCode = genreCode + "G";
                Genres++;
            }

            if (CheckH.IsChecked == true)
            {
                genreCode = genreCode + "H";
                Genres++;
            }

            if (CheckI.IsChecked == true)
            {
                genreCode = genreCode + "I";
                Genres++;
            }

            if (CheckJ.IsChecked == true)
            {
                genreCode = genreCode + "J";
                Genres++;
            }

            if (CheckK.IsChecked == true)
            {
                genreCode = genreCode + "K";
                Genres++;
            }

            if (CheckL.IsChecked == true)
            {
                genreCode = genreCode + "L";
                Genres++;
            }

            if (CheckM.IsChecked == true)
            {
                genreCode = genreCode + "M";
                Genres++;
            }

            if (CheckN.IsChecked == true)
            {
                genreCode = genreCode + "N";
                Genres++;
            }

            if (CheckO.IsChecked == true)
            {
                genreCode = genreCode + "O";
                Genres++;
            }

            string filePath = @"C:\Users\270197547\OneDrive - UP Education\Documents\2024 programming\106.2 main assesment\MainWebsite\Books.csv";

            // Check if file exists; if not, create it and add headers
            if (!File.Exists(filePath))
            {
                using (var writer = new StreamWriter(filePath, append: true))
                {
                    writer.WriteLine("Book Name,Author Name,Published Date,Number of Pages,Description,Review, Genre code");
                }
            }

            // Append the book details to the CSV file
            using (var writer = new StreamWriter(filePath, append: true))
            {
                writer.WriteLine($"{title},{author},{PDate},{numberOfPages},{description},{review},{genreCode}");
            }

            // Notify the user
            MessageBox.Show("Book details saved successfully!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);

            MainWindow HomePage = new MainWindow();

            //Show window3
            HomePage.Show();

            //Close the main window (optional)
            this.Close();
        }
    }
}
