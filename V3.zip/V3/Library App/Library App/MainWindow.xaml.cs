﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Library_App
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void LogInButton_Click(object sender, RoutedEventArgs e)
        {
            //Gets the data from the user
            string EnteredUsername = UserNameInput.Text;
            string EnteredPassword = PasswordInput.Password;

            // Check if the user exists in the CSV file
            if (ValidateUserLogin(EnteredUsername, EnteredPassword))
            {
                MessageBox.Show("Login successful!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                // Proceed to the next window or functionality
                Window1 window1 = new Window1();

                //Show window3
                window1.Show();

                //Close the main window (optional)
                this.Close();
            }
            else
            {
                MessageBox.Show("Invalid username or password.", "Login Failed", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private bool ValidateUserLogin(string username, string password)
        {
            // Define the path to the CSV file
            string filePath = @"C:\Users\270197547\OneDrive - UP Education\Documents\2024 programming\106.2 main assesment\MainWebsite\Accounts.csv";

            try
            {
                // Read all lines from the CSV file
                var lines = File.ReadAllLines(filePath);
                MessageBox.Show($"Entered Username: {username}\nEntered Password: {password}", "Entered Credentials");

                // Debugging: Show the full content of the CSV file for review
                string fileContent = string.Join("\n", lines);
                MessageBox.Show("CSV File Content:\n" + fileContent, "CSV Debug Info");

                // Skip the header and check each line for matching credentials
                foreach (var line in lines.Skip(1)) // Skip the first line if it's a header
                {
                    var values = line.Split(',');

                    // Assuming CSV format is: Username,Password
                    if (values.Length >= 2)
                    {
                        string csvUsername = values[0].Trim();
                        string csvPassword = values[1].Trim();
                        string csvAdmin = values[4].Trim();

                        // Compare the entered credentials with the ones in the CSV
                        if (csvUsername.Equals(username, StringComparison.OrdinalIgnoreCase) && csvPassword == password)
                        {
                            return true; // Credentials match
                        }
                    }

                    else
                    {
                        // Debugging: Show an error if the line format is unexpected
                        MessageBox.Show("Unexpected line format in CSV file: " + line, "Format Error");
                    }
                }
            }
            catch (FileNotFoundException)
            {
                MessageBox.Show("Accounts file not found. Please check the file path.", "File Not Found", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error reading the accounts file: " + ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }

            // Return false if no match is found or an error occurred
            return false;
        }

        private void CreateAccount(object sender, RoutedEventArgs e)
        {
            //Create an instance of window3
            Window2 window2 = new Window2();

            //Show window3
            window2.Show();

            //Close the main window (optional)
            this.Close();
        }


    }
}
