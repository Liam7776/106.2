﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Library_App
{
    /// <summary>
    /// Interaction logic for Window5.xaml
    /// </summary>
    public partial class Window5 : Window
    {
        private string UserName;
        private string Password;
        private string DateOfBirth;
        private string PhoneNum;
        public Window5(string userName, string Password, string DOB, string PhoneNumber)
        {
            InitializeComponent();
            this.UserName = userName;
            this.Password = Password;
            this.DateOfBirth = DOB;
            this.PhoneNum = PhoneNumber;

        }


        private void AdminConfirm_Click(object sender, RoutedEventArgs e)
        {
            string EnteredCode = Admin_Code_input.Text;

            if (EnteredCode == "L18r@117e")
            {
                string filePath = @"C:\Users\270197547\OneDrive - UP Education\Documents\2024 programming\106.2 main assesment\MainWebsite\Accounts.csv";

                // Check if file exists; if not, create it and add headers
                if (!File.Exists(filePath))
                {
                    using (var writer = new StreamWriter(filePath, append: true))
                    {
                        writer.WriteLine("Username,Password,Date of Birth,Phone Number", "Admin");
                    }
                }

                // Append the book details to the CSV file
                using (var writer = new StreamWriter(filePath, append: true))
                {
                    writer.WriteLine($"{UserName},{Password},{DateOfBirth},{PhoneNum}, Y");
                }

                MessageBox.Show("Accout successfully created!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);

                MainWindow HomePage = new MainWindow();

                //Show window3
                HomePage.Show();

                //Close the main window (optional)
                this.Close();
            }

            else
            {
                Admin_Code_input.Clear();
                MessageBox.Show("Invalid code", "Failed", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }
    }
}
