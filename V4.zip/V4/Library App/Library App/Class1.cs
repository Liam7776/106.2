﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library_App
{
    public class Book
    {
        public string BooksName { get; set; }
        public string Author { get; set; }
        public string Image { get; set; }
    }
}
