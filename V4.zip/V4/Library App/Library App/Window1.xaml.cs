﻿using System;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;

namespace Library_App
{
    public partial class Window1 : Window
    {
        public Window1()
        {
            InitializeComponent();
            GetBooks();
        }

        private void AddBook(object sender, RoutedEventArgs e)
        {
            Window3 window3 = new Window3();
            window3.Show();
            this.Close();
        }

        private void LogIn(object sender, RoutedEventArgs e)
        {
            Window1 window1 = new Window1();
            window1.Show();
            this.Close();
        }

        private void GetBooks()
        {
            string filePath = @"C:\Users\270197547\OneDrive - UP Education\Documents\2024 programming\106.2 main assesment\MainWebsite\Library App\Library App\Books.csv";

            try
            {
                var lines = File.ReadAllLines(filePath);

                foreach (var line in lines.Skip(1)) // Skip the header line
                {
                    var values = line.Split(',');

                    if (values.Length >= 10)
                    {
                        string BooksName = values[0].Trim();
                        string Author = values[1].Trim();
                        string PublishedDate = values[2].Trim();
                        string PageNum = values[3].Trim();
                        string Description = values[4].Trim();
                        string ReviewScore = values[5].Trim();
                        string Genres = values[6].Trim();
                        string InStock = values[7].Trim();
                        string Owner = values[8].Trim();
                        string ImagePath = values[9].Trim();

                        // Create a new StackPanel for each book
                        StackPanel bookPanel = new StackPanel { Orientation = Orientation.Vertical, Margin = new Thickness(5) };

                        // Load the image
                        Image bookImage = new Image { Width = 100, Height = 150, Margin = new Thickness(0, 0, 0, 5) };
                        BitmapImage bitmap = new BitmapImage();
                        bitmap.BeginInit();
                        bitmap.UriSource = new Uri(ImagePath, UriKind.Absolute);
                        bitmap.EndInit();
                        bookImage.Source = bitmap;

                        // Add book data
                        TextBlock titleBlock = new TextBlock { Text = "Title: " + BooksName, FontWeight = FontWeights.Bold };
                        TextBlock authorBlock = new TextBlock { Text = "Author: " + Author };
                        TextBlock dateBlock = new TextBlock { Text = "Published Date: " + PublishedDate };
                        TextBlock pageBlock = new TextBlock { Text = "Pages: " + PageNum };
                        TextBlock descriptionBlock = new TextBlock { Text = "Description: " + Description };
                        TextBlock genreBlock = new TextBlock { Text = "Genre: " + Genres };

                        // Add the image and details to the book panel
                        bookPanel.Children.Add(bookImage);
                        bookPanel.Children.Add(titleBlock);
                        bookPanel.Children.Add(authorBlock);
                        bookPanel.Children.Add(dateBlock);
                        bookPanel.Children.Add(pageBlock);
                        bookPanel.Children.Add(descriptionBlock);
                        bookPanel.Children.Add(genreBlock);

                        // Add each book panel to the main BooksPanel
                        BooksPanel.Children.Add(bookPanel);
                    }
                    else
                    {
                        MessageBox.Show("Unexpected line format in CSV file: " + line, "Format Error");
                    }
                }
            }
            catch (FileNotFoundException)
            {
                MessageBox.Show("Accounts file not found. Please check the file path.", "File Not Found", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error reading the accounts file: " + ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}