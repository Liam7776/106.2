﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Library_App
{

    /// <summary>
    /// Interaction logic for ModifyBooks.xaml
    /// </summary>
    /// This allows the admin user to view the full book catalogue as well as either modify book information or delete the book
    public partial class ModifyBooks : Window
    {
        /// // List to store book objects
        private List<BookDetails> bookCatalogue = new List<BookDetails>();
        public string CurrentUser;
        public string Admin;
        private string GenreList;

        public ModifyBooks(string user, string admin)
        {
            CurrentUser = user;
            Admin = admin;

            //UserOptionLabel.Content = CurrentUser;
            InitializeComponent();
            GetBooks();
        }

        //Loops through the book CSV and adds the books to the catalogue list
        private void GetBooks()
        {
            string filePath = @"C:\Users\270197547\OneDrive - UP Education\Documents\2024 programming\106.2 main assesment\MainWebsite\Library App\Library App\Books.csv";
            //string filePath = @"C:\2024 Yoobee work\Term 4 home\106 home\MainWebsite\Library App\Library App\Books.csv";

            try
            {
                var lines = File.ReadAllLines(filePath);

                // Loop through each line in the CSV file (skipping the header)
                foreach (var line in lines.Skip(1))
                {
                    var values = line.Split(',');

                    if (values.Length >= 11) // Ensure all fields are present
                    {
                        //Calls and creates the bookDetails object
                        var book = new BookDetails(
                            values[0].Trim(), values[1].Trim(), values[2].Trim(),
                            values[3].Trim(), values[4].Trim(), values[5].Trim(),
                            values[6].Trim(), values[7].Trim(), values[8].Trim(),
                            values[9].Trim(), values[10].Trim()
                        );

                        // Add each book object to the list
                        bookCatalogue.Add(book);

                        // Create a StackPanel for each book entry
                        StackPanel bookEntryPanel = new StackPanel { Orientation = Orientation.Horizontal, Background = new SolidColorBrush(Color.FromRgb(255, 223, 145)), Margin = new Thickness(5), Width = 800, Height = 250 };

                        // Create and add book image
                        Image bookImage = new Image { Width = 150, Height = 200, Margin = new Thickness(10, 10, 20, 10) };
                        BitmapImage bitmap = new BitmapImage();
                        bitmap.BeginInit();
                        bitmap.UriSource = new Uri(book.ImageLink, UriKind.Absolute);
                        bitmap.EndInit();
                        bookImage.Source = bitmap;
                        bookEntryPanel.Children.Add(bookImage);

                        // Create a StackPanel for book details
                        StackPanel bookDetailsPanel = new StackPanel { Orientation = Orientation.Vertical, Margin = new Thickness(10) };
                        TextBlock titleBlock = new TextBlock { Text = "Title: " + book.Title, FontWeight = FontWeights.Bold };
                        TextBlock authorBlock = new TextBlock { Text = "Author: " + book.Author };
                        TextBlock dateBlock = new TextBlock { Text = "Published Date: " + book.PublishedDate };
                        TextBlock pageBlock = new TextBlock { Text = "Pages: " + book.PageNum };
                        GenreList = setGenres(book.GenreCode); //Sets the genre string for the book
                        TextBlock genreBlock = new TextBlock { Text = GenreList };

                        // Add all details to the details panel
                        bookDetailsPanel.Children.Add(titleBlock);
                        bookDetailsPanel.Children.Add(authorBlock);
                        bookDetailsPanel.Children.Add(dateBlock);
                        bookDetailsPanel.Children.Add(pageBlock);
                        bookDetailsPanel.Children.Add(genreBlock);

                        TextBlock availabilityBlock;

                        // Determine availability status and add appropriate text block
                        //If book Status == 1, then if hasn't been rented yet
                        if (book.Status == "1")
                        {
                            availabilityBlock = new TextBlock { Text = "Available", FontWeight = FontWeights.Bold };
                            bookDetailsPanel.Children.Add(availabilityBlock);
                        }
                        //If book status == 0 then it's been rented, the code then checks the current owner and sees if it's the same as the current user
                        else if (book.Status == "0" && book.CurrentOwner == CurrentUser)
                        {
                            availabilityBlock = new TextBlock { Text = "You own: Due Date: " + book.ReturnDate, FontWeight = FontWeights.Bold }; //If this is the case, then it'll display the due date for the book
                            bookDetailsPanel.Children.Add(availabilityBlock);
                        }
                        //If the book is out and rented by someone
                        else
                        {
                            availabilityBlock = new TextBlock { Text = "Unavailable: Rented by: " + book.CurrentOwner, FontWeight = FontWeights.Bold };
                            TextBlock DueDateBlock = new TextBlock { Text = "Due Date: " + book.ReturnDate, FontWeight = FontWeights.Bold };
                            bookDetailsPanel.Children.Add(availabilityBlock);
                            bookDetailsPanel.Children.Add(DueDateBlock);
                        }


                        bookEntryPanel.Children.Add(bookDetailsPanel);

                        // Create a StackPanel for buttons (Delete and Modify)
                        StackPanel buttonPanel = new StackPanel { Orientation = Orientation.Vertical, HorizontalAlignment = HorizontalAlignment.Right, Margin = new Thickness(20, 10, 10, 10) };

                        // Create Delete button
                        Button deleteButton = new Button { Content = "Delete", Width = 100, Height = 40, Margin = new Thickness(0, 0, 0, 50), Background = Brushes.LightGray };
                        deleteButton.Click += (s, e) => DeleteBook(book);
                        deleteButton.IsEnabled = book.Status == "1"; // Only enable if the book is available
                        buttonPanel.Children.Add(deleteButton);

                        // Create Modify button
                        Button modifyButton = new Button { Content = "Modify", Width = 100, Height = 40, Background = Brushes.LightGray };
                        modifyButton.Click += (s, e) => ModifyBook(book);
                        modifyButton.IsEnabled = book.Status == "1"; // Only enable if the book is available
                        buttonPanel.Children.Add(modifyButton);

                        bookEntryPanel.Children.Add(buttonPanel);

                        // Add the entire entry to the main BooksPanel (vertical scrolling panel)
                        BooksPanel.Children.Add(bookEntryPanel);
                    }
                    else
                    {
                        MessageBox.Show("Unexpected line format in CSV file: " + line, "Format Error");
                    }
                }
            }
            catch (FileNotFoundException)
            {
                MessageBox.Show("Books file not found. Please check the file path.", "File Not Found", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error reading the books file: " + ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        //This is used when getting the genre, the book is stored as a code of letters (A to 0), and each letter corespsonds with a genre
        private Dictionary<char, string> genreDescriptions = new Dictionary<char, string>
        {
            { 'A', "Action and Adventure" },
            { 'B', "Biography" },
            { 'C', "Comedy" },
            { 'D', "Drama" },
            { 'E', "Children Books" },
            { 'F', "Fantasy" },
            { 'G', "Graphic Novel/Comic" },
            { 'H', "Horror" },
            { 'I', "Sci-fi" },
            { 'J', "Romance" },
            { 'K', "War" },
            { 'L', "Thriller" },
            { 'M', "Mystery" },
            { 'N', "Non-fiction" },
            { 'O', "Other" }
        };

        //Loops through the genre code and adds a genre to the genrelist string for each letter
        private string setGenres(string Code)
        {
            GenreList = "Genres: ";
            foreach (char code in Code)
            {
                if (genreDescriptions.ContainsKey(code))
                {
                    GenreList += genreDescriptions[code] + ", ";
                }
                else
                {
                    GenreList += "Unknown Genre, ";
                }
            }

            // Trim the trailing comma and space
            GenreList = GenreList.TrimEnd(',', ' ');

            return GenreList;
        }

        //If the user chooses to delete a book
        private void DeleteBook(BookDetails book)
        {
            // Path to the PreOrderList CSV file
            string preOrderFilePath = @"C:\Users\270197547\OneDrive - UP Education\Documents\2024 programming\106.2 main assesment\MainWebsite\Library App\Library App\PreOrderList.csv";
            //string preOrderFilePath = @"C:\2024 Yoobee work\Term 4 home\106 home\MainWebsite\Library App\Library App\PreOrderList.csv";
            // Step 1: Remove the book from Books.csv (catalog file)
            // string bookFilePath = @"C:\Users\270197547\OneDrive - UP Education\Documents\2024 programming\106.2 main assesment\MainWebsite\Library App\Library App\Books.csv";
            string bookFilePath = @"C:\2024 Yoobee work\Term 4 home\106 home\MainWebsite\Library App\Library App\Books.csv";
            var lines = File.ReadAllLines(bookFilePath).ToList();
            lines = lines.Where(line => !line.StartsWith(book.Title + ",")).ToList(); // Remove lines matching the book title
            File.WriteAllLines(bookFilePath, lines);

            // Step 2: Remove the book from PreOrderList.csv
            if (File.Exists(preOrderFilePath))
            {
                var preOrderLines = File.ReadAllLines(preOrderFilePath).ToList();
                // Filter out any line where the book title matches the one we are deleting
                preOrderLines = preOrderLines.Where(line => !line.StartsWith(book.Title + ",")).ToList();
                // Write updated content back to PreOrderList.csv
                File.WriteAllLines(preOrderFilePath, preOrderLines);
            }

            // Step 3: Refresh the UI (remove the book from bookCatalogue and update BooksPanel if necessary)
            bookCatalogue.Remove(book);
            BooksPanel.Children.Clear();
            GetBooks();

            MessageBox.Show($"Book '{book.Title}' has been deleted from the catalog and pre-order list.", "Delete Action", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        //The user has chosen to modify the book
        private void ModifyBook(BookDetails book)
        {
            //Calls window 3 (Normally the add new book window), ad passes "MDBook" as the change string, which will tell the code that the book is being modified, instead of added
            Window3 window3 = new Window3(CurrentUser, Admin, "MDBook", book.Title); //MDBook means modify book, which is passed so that the code knows to only update the book in the csv
            window3.Show();
            this.Close();
        }



        //Takes the user back to the home page
        private void ReturnHome_Click(object sender, RoutedEventArgs e)
        {
            //Create an instance of window1
            Window1 window1 = new Window1(CurrentUser, Admin);

            //Show window1
            window1.Show();

            //Close the main window (optional)
            this.Close();
        }

        //The user chooses to sign out
        private void LogOut_Click(object sender, RoutedEventArgs e)
        {
            MainWindow main = new MainWindow();
            main.Show();
            this.Close();
        }

    }
}
