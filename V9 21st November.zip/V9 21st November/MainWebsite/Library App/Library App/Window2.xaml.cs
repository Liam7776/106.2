﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static System.Net.Mime.MediaTypeNames;

namespace Library_App
{
    /// <summary>
    /// Interaction logic for Window2.xaml
    /// </summary>
    public partial class Window2 : Window
    {
        public string CurrentUser;
        public string Admin;
        public string Next; //This variable is used to determine what to do after the account is created, based on weather the user creates an account or admin adds a new account
        //If the user is is creating they're own account when logging in, then the code will ask them to log in with the new account, and if it's an admin user creating the account then it just goes back to the home page
        //There are 2 things Next can be, "CAC" for Creating account (Used if the user is creating they're own account) and "AAC" for Add Account (Used if an admin user is creating the account themselves).
        //Theres also "MDAC", which stands for modify acount, this is used for when the user just wants to update the account
        public string OriginalAccount;
        public string AdminAssign;
        public Window2(string user, string admin, string N, string OGN)
        {
            InitializeComponent();
            CurrentUser = user;
            Admin = admin;
            Next = N;
            OriginalAccount = OGN;

            if (N == "CAC" || N == "AAC") //Will display create account if a new account is being created
            {
                SignUpButton.Visibility = Visibility.Visible;
                ModifyButton.Visibility = Visibility.Collapsed;
                TextBlock AccountHeader = new TextBlock { Text = "Create Account", FontSize = 40};
                AccountAction.Content = AccountHeader;
            }

            else if (N == "MDAC") //Will display modify account if the account's information is being modified
            {
                SignUpButton.Visibility = Visibility.Collapsed;
                ModifyButton.Visibility = Visibility.Visible;
                TextBlock AccountHeader = new TextBlock { Text = "Modify Account", FontSize = 40};
                AccountAction.Content = AccountHeader;
            }
        }

        private void SignUpButton_Click(object sender, RoutedEventArgs e)
        {
            //Capturing data from textboxes
            string UserName = EnterUserName.Text;
            string Password = EnterPassword.Text;
            string DateOfBirth = $"{MonthTextBox.Text}/{DayTextBox.Text}/{YearTextBox.Text}";
            string PhoneNum = EnterPhoneNumber.Text;

            string Month = MonthTextBox.Text;
            string Day = DayTextBox.Text;
            string Year = YearTextBox.Text;

            bool Create = true; //If at any point create is turned to false; then the code will inform the user that the entered data wasn't entered correctly
            //Checks to ensure that the entered data is correct
            if (UserName.Length == 0 || Password.Length == 0 || DateOfBirth.Length != 10 || PhoneNum.Length == 0)
            {
                MessageBox.Show("Please enter all the requested data correctly", "Failed", MessageBoxButton.OK, MessageBoxImage.Information);
                Create = false;
            }

            //Checks all the major data to ensure there are no commas (",")
            Create = InfoCheck(UserName, Password, PhoneNum, Month, Day, Year, Create);


            if (Create == true)
            {
                if (AdminCheck.IsChecked == true)
                {
                    Window5 window5 = new Window5(UserName, Password, DateOfBirth, PhoneNum, CurrentUser, Admin, Next);

                    //Show window3
                    window5.Show();

                    //Close the main window (optional)
                    this.Close();
                }

                else if (AdminCheck.IsChecked == false)
                {
                    string filePath = @"C:\Users\270197547\OneDrive - UP Education\Documents\2024 programming\106.2 main assesment\MainWebsite\Library App\Library App\Accounts.csv";
                    //string filePath = @"C:\2024 Yoobee work\Term 4 home\106 home\MainWebsite\Library App\Library App\Accounts.csv";

                    // Check if file exists; if not, create it and add headers
                    if (!File.Exists(filePath))
                    {
                        using (var writer = new StreamWriter(filePath, append: true))
                        {
                            writer.WriteLine("Username,Password,Date of Birth,Phone Number","Admin");
                        }
                    }

                    // Append the book details to the CSV file
                    using (var writer = new StreamWriter(filePath, append: true))
                    {
                        writer.WriteLine($"{UserName},{Password},{DateOfBirth},{PhoneNum}, N");
                    }

                    MessageBox.Show("Accout successfully created!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);

                    //Checks what next is equal to to determine weather to go back to the library so that the current Admin user who created the account stays logged in, or if the new user who made they're account themselves goes back to the log in page

                    if (Next == "CAC") //"CAC" stands for Creating account (Used if the user is creating they're own account), and will send the user back to the log in screen
                    {
                        MainWindow Main = new MainWindow();

                        //Show the main page (The log in screen)
                        Main.Show();

                        //Close the main window (optional)
                        this.Close();
                    }

                    else if (Next == "AAC") //"AAC" stands for Adding and account (Used if the admin user adds the account), and will send the user back to the log in screen
                    {
                        Window1 Window1 = new Window1(CurrentUser, Admin);

                        Window1.Show();
                        this.Close();
                    }

                }

            }

            else if (Create == false)
            {
                MessageBox.Show("Please enter all the requested data correctly", "Failed", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            
        }


        //Checks each character entered to ensure there are no commas, or other errors
        private bool InfoCheck(string USN, string PSW, string PhoneNum, string M, string D, string Y, bool OG)
        {
            //CHecks the username
            foreach (char Character in USN)
            {
                if (Character == ',')
                {
                    return false;
                }
            }

            //Checks the password
            foreach (char Character in PSW)
            {
                if (Character == ',' || Character == ' ') //Checks to ensure there is not spaces as well as commas
                {
                    return false;
                }
            }

            //Checks the phone number
            foreach (char Character in PhoneNum)
            {
                if (Character == ',')
                {
                    return false;
                }
            }

            try
            {
                int PN = Int32.Parse(PhoneNum);
            }
            catch (FormatException e)
            {
                Console.WriteLine(e.Message);
                return false;
            }

            //Checking the invidual date data to see if it's numbers, as well as weather or not the data entered is valid or not
            try
            {
                int Month = Int32.Parse(M);
                if (Month > 12 || Month <= 0)
                {
                    return false;
                }
            }
            catch (FormatException e)
            {
                Console.WriteLine(e.Message);
                return false;
            }

            try
            {
                int Day = Int32.Parse(D);
                if (Day <= 0)
                {
                    return false;
                }
            }
            catch (FormatException e)
            {
                Console.WriteLine(e.Message);
                return false;
            }

            try
            {
                int Year = Int32.Parse(Y);
                if (Year <= 1900)
                {
                    return false;
                }
            }
            catch (FormatException e)
            {
                Console.WriteLine(e.Message);
                return false;
            }

            return OG;
        }

        private void ModifyButton_Click(object sender, RoutedEventArgs e)
        {
            //Capturing data from textboxes
            string UserName = EnterUserName.Text;
            string Password = EnterPassword.Text;
            string DateOfBirth = $"{MonthTextBox.Text}/{DayTextBox.Text}/{YearTextBox.Text}";
            string PhoneNum = EnterPhoneNumber.Text;

            string Month = MonthTextBox.Text;
            string Day = DayTextBox.Text;
            string Year = YearTextBox.Text;

            bool Create = true; //If at any point create is turned to false; then the code will inform the user that the entered data wasn't entered correctly
            //Checks to ensure that the entered data is correct
            if (UserName.Length == 0 || Password.Length == 0 || DateOfBirth.Length != 10 || PhoneNum.Length == 0)
            {
                MessageBox.Show("Please enter all the requested data correctly", "Failed", MessageBoxButton.OK, MessageBoxImage.Information);
                Create = false;
            }

            //Checks all the major data to ensure it is all entered corrctly
            Create = InfoCheck(UserName, Password, PhoneNum, Month, Day, Year, Create);

            if (Create == true)
            {
                if (AdminCheck.IsChecked == true)
                {
                    AdminAssign = "Y";
                }

                else if (AdminCheck.IsChecked == false)
                {
                    AdminAssign = "N";
                }

                //Once all the data is collected, the code then checks the accounts and updates they're data

                string AccountfilePath = @"C:\Users\270197547\OneDrive - UP Education\Documents\2024 programming\106.2 main assesment\MainWebsite\Library App\Library App\Accounts.csv";
                try
                {
                    var lines = File.ReadAllLines(AccountfilePath);
                    for (int i = 1; i < lines.Length; i++)
                    {
                        var values = lines[i].Split(',');

                        // Check if this line corresponds to the original account name
                        if (values[0].Trim() == OriginalAccount)
                        {
                            // Update values for current status, owner, and return date
                            values[0] = UserName;
                            values[1] = Password;
                            values[2] = DateOfBirth;
                            values[3] = PhoneNum;
                            values[4] = AdminAssign;

                            // Update the line in the array
                            lines[i] = string.Join(",", values);
                            break;
                        }
                    }

                    // Write all lines back to the CSV file
                    File.WriteAllLines(AccountfilePath, lines);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error updating CSV file: " + ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }

                MessageBox.Show("User" + OriginalAccount + "details were succesfully updated", "Success", MessageBoxButton.OK, MessageBoxImage.Information);

                Window1 HomePage = new Window1(CurrentUser, Admin);

                //Show window1
                HomePage.Show();

                //Close the main window (optional)
                this.Close();
            }

            else if (Create == false)
            {
                MessageBox.Show("Please enter all the requested data correctly", "Failed", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            //If it's a new user making they're own account, then it returns to the log in screen
            if (Next == "CAC")
            {
                MainWindow main = new MainWindow();
                main.Show();
                this.Close();
            }

            //If it's an admin user eithr adding a new account, or modifying an account, it'll just go back to the home screen
            else if (Next == "AAC" || Next == "MDAC")
            {
                Window1 Homrscreen = new Window1(CurrentUser, Admin);
                Homrscreen.Show();
                this.Close();
            }

        }

    }
}