﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static System.Net.Mime.MediaTypeNames;
using static System.Net.WebRequestMethods;

namespace Library_App
{
    public partial class Window3 : Window
    {
        public string CurrentUser;
        public string Admin;
        public string Change; //This variable is used to determine weather or not to add a new book or just update it's information
        public string OriginalBookName;
        public Window3(string user, string admin, string change, string OGName)
        {
            InitializeComponent();
            // Clear input fields after saving
            BookNameTextBox.Clear();
            AuthorNameTextBox.Clear();
            DayTextBox.Clear();
            MonthTextBox.Clear();
            YearTextBox.Clear();
            PagesTextBox.Clear();
            DescriptionTextBox.Clear();
            ReviewTextBox.Clear();

            //Setting up variables for the user
            CurrentUser = user;
            Admin = admin;
            Change = change;
            OriginalBookName = OGName;

            if (Change == "ADBook") //If an admin user is just adding a new book
            {
                TextBlock BookHeader = new TextBlock { Text = "Add book", FontSize = 35 };
                BookAction.Content = BookHeader;
            }

            else if (Change == "MDBook") //If an admin user is modifying the book
            {
                TextBlock BookHeader = new TextBlock { Text = "Modify book", FontSize = 35 };
                BookAction.Content = BookHeader;
            }

        }

        //This is used to give the user instructions on how to get the image
        private void ImageInstructions_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("First go to imgbb (Link:https://imgbb.com/) and drag and drop an image of the books cover", "Image instructions", MessageBoxButton.OK, MessageBoxImage.Information);
            MessageBox.Show("Once you've dragged the image, and then hit upload. Then open the link that appears in another window", "Image instructions", MessageBoxButton.OK, MessageBoxImage.Information);
            MessageBox.Show("Then right click on the image and choose open in new tab, then copy the link for that window into the image link box", "Image instructions", MessageBoxButton.OK, MessageBoxImage.Information);
            MessageBox.Show("Just note that if you don't upload an image link, the code will instead use a placeholder image", "Image instructions", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void NextButton_Click(object sender, RoutedEventArgs e)
        {
            // Capture data from TextBoxes
            string bookName = BookNameTextBox.Text;
            bookName = bookName.ToLower();
            string authorName = AuthorNameTextBox.Text;
            authorName = authorName.ToLower();
            string publishedDate = $"{MonthTextBox.Text}/{DayTextBox.Text}/{YearTextBox.Text}";
            string numberOfPages = PagesTextBox.Text;
            string description = DescriptionTextBox.Text;
            string review = ReviewTextBox.Text;
            string imageCode = imageLinkTextBox.Text;


            bool Next = true;
            //Checks to see/ensure that all the data has actually been entered correctly
            if (bookName.Length == 0 || authorName.Length == 0 || numberOfPages.Length == 0 || description.Length == 0 
                || review.Length == 0 || publishedDate.Length != 10)
            {
                Next = false;
            }

            if (imageCode.Length == 0)
            {
                imageCode = "https://i.ibb.co/HVJ59QM/Placeholder-book-cover.jpg";
            }

            //Checks the description to ensure there are no commas
            Next = DataCheck(bookName, authorName, description, review, numberOfPages, Next);


            //If all the book data entered checks out
            if (Next == true)
            {
                Window4 window4 = new Window4(bookName, authorName, publishedDate, numberOfPages, description, review, imageCode, CurrentUser, Admin, Change, OriginalBookName);

                //Show window3
                window4.Show();

                //Close the main window (optional)
                this.Close();
            }

            else if (Next == false)
            {
                MessageBox.Show("Please enter all the requested data correctly", "Failed", MessageBoxButton.OK, MessageBoxImage.Information);
            }

        }
        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            Window1 Homrscreen = new Window1(CurrentUser, Admin);
            Homrscreen.Show();
            this.Close();
        }


        //Checks each character entered to that it's valid (Checks for commas and if the numbers entered are actually numbers)
        private bool DataCheck(string Name, string Author, string Desc, string Review, string PageNum, bool OG)
        {
            foreach (char Character in Name)
            {
                if (Character == ',')
                {
                    return false;
                }
            }

            foreach (char Character in Author)
            {
                if (Character == ',')
                {
                    return false;
                }
            }

            foreach (char Character in Desc)
            {
                if (Character == ',')
                {
                    return false;
                }
            }

            foreach (char Character in Review)
            {
                if (Character == ',')
                {
                    return false;
                }

            }

            //Checks to ensure that the number of pages is not only an actual number, but also weather or not it's even
            try
            {
                int Pages = Int32.Parse(PageNum);
                if (Pages % 2 != 0)
                {
                    return false;
                }
            }
            catch (FormatException e)
            {
                Console.WriteLine(e.Message);
                return false;

            }

            return OG;
        }

    }
}