﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Policy;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;

namespace Library_App
{
    public partial class AdminOptions : Window
    {
        public string CurrentUser;
        public string Admin;
        // List to store book objects
        private List<BookDetails> booksList = new List<BookDetails>();

        //public Window1(string userName, char admin)
        public AdminOptions(string userName, string admin)
        {
            InitializeComponent();

            CurrentUser = userName;
            Admin = admin;

            booksList.Clear();
        }


        private void Add_Book(object sender, RoutedEventArgs e)
        {
            Window3 window3 = new Window3(CurrentUser, Admin, "ADBook", "none"); //AdBook is passes when the user wishes to add a new book
            window3.Show();
            this.Close();
        }

        private void Add_Account(object sender, RoutedEventArgs e)
        {
            Window2 Main = new Window2(CurrentUser, Admin, "AAC");
            Main.Show();
            this.Close();
        }

        private void HomeButton(object sender, RoutedEventArgs e)
        {
            Window1 Main = new Window1(CurrentUser, Admin);
            Main.Show();
            this.Close();
        }

        private void ViewAccounts(object sender, RoutedEventArgs e)
        {
            ModifyUsers userViewer = new ModifyUsers(CurrentUser, Admin);
            userViewer.Show();
            this.Close();
        }

        private void ViewBook(object sender, RoutedEventArgs e)
        {
            ModifyBooks BookViewer = new ModifyBooks(CurrentUser, Admin);
            BookViewer.Show();
            this.Close();
        }

    }
}