﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library_App
{
    /*public class BookDetails
    {
        public string BooksName { get; set; }
        public string Author { get; set; }
        public string Image { get; set; }
    }*/


    public class BookDetails
    {
        public BookDetails(string title, string author, string PDate, string Pages, string desc, string Score, string Genres, string status, string owner, string RDate, string image) 
        { 
            Title = title;
            Author = author;
            PublishedDate = PDate;
            PageNum = Pages;
            Desc = desc;
            ReviewScore = Score;
            GenreCode = Genres;
            Status = status;
            CurrentOwner = owner;
            ReturnDate = RDate;
            ImageLink = image;
        }

        public string Title { get; set; } //The books title
        public string Author { get; set; } //THe books Author
        public string PublishedDate { get; set; } //The date the book was published
        public string PageNum { get; set; } //The number of pages
        public string Desc { get; set; } //A story description
        public string ReviewScore { get; set; } //The books review score (Out of 5)
        public string GenreCode { get; set; } //The grenre code, which is used to get the genres for the book
        public string Status { get; set; } //The current status of the book, IE weather or not it's currently rented
        public string CurrentOwner { get; set; } //The current owner of the book
        public string ReturnDate { get; set; } //The date when the book needs to be returned (If it's been rented)
        public string ImageLink { get; set; } // The link used to get/display the books cover

    }
}
