﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Library_App
{

    /// <summary>
    /// Interaction logic for ModifyBooks.xaml
    /// </summary>
    public partial class ModifyUsers : Window
    {
        /// // List to store book objects
        private List<UserClass> AccountList = new List<UserClass>();
        public string CurrentUser;
        public string Admin;


        public ModifyUsers(string user, string admin)
        {
            CurrentUser = user;
            Admin = admin;

            InitializeComponent();
            GetUsers();
        }

        private void GetUsers()
        {
            string filePath = @"C:\Users\270197547\OneDrive - UP Education\Documents\2024 programming\106.2 main assesment\MainWebsite\Library App\Library App\Accounts.csv";

            try
            {
                var lines = File.ReadAllLines(filePath);
                int RentedBooks = 0;
                int Preorders = 0;
                int Totals = 0;


                // Loop through each line in the CSV file (skipping the header)
                foreach (var line in lines.Skip(1))
                {
                    var values = line.Split(',');

                    if (values.Length >= 5) // Ensure all fields are present
                    {
                        var user = new UserClass(
                            values[0].Trim(), values[1].Trim(), values[2].Trim(),
                            values[3].Trim(), values[4].Trim());


                        // Add each user object to the list
                        AccountList.Add(user);

                        // Create a StackPanel for each user
                        StackPanel UserEntryPanel = new StackPanel { Orientation = Orientation.Horizontal, Background = new SolidColorBrush(Color.FromRgb(255, 223, 145)), Margin = new Thickness(5), Width = 400, Height = 250 };


                        // Create a StackPanel for data on the user
                        StackPanel UserDetailsPanel = new StackPanel { Orientation = Orientation.Vertical, Margin = new Thickness(10) };
                        TextBlock UserBlock = new TextBlock { Text = "User: " + user.UserName, FontWeight = FontWeights.Bold };
                        TextBlock DobBlock = new TextBlock { Text = "Date of birth: " + user.DateOfBirth };
                        TextBlock PhoneBlock = new TextBlock { Text = "Phone number: " + user.PhoneNumber };
                        TextBlock AdminBlock = new TextBlock { Text = "Is admin: " + user.Admin };
                        RentedBooks = countRents(user.UserName);
                        Preorders = 0;
                        Totals = RentedBooks + Preorders;
                        TextBlock bookStatus = new TextBlock {Text = "Rented Books: " + RentedBooks + " : Pre-ordered books: " + Preorders };

                        // Add all details to the details panel
                        UserDetailsPanel.Children.Add(UserBlock);
                        UserDetailsPanel.Children.Add(DobBlock);
                        UserDetailsPanel.Children.Add(PhoneBlock);
                        UserDetailsPanel.Children.Add(AdminBlock);
                        UserDetailsPanel.Children.Add(bookStatus);



                        UserEntryPanel.Children.Add(UserDetailsPanel);

                        // Create a StackPanel for buttons (Delete and Modify)
                        StackPanel buttonPanel = new StackPanel { Orientation = Orientation.Vertical, HorizontalAlignment = HorizontalAlignment.Right, Margin = new Thickness(20, 10, 10, 10) };

                        // Create Delete button
                        Button deleteButton = new Button { Content = "Delete", Width = 100, Height = 40, Margin = new Thickness(0, 0, 0, 50), Background = Brushes.LightGray };
                        deleteButton.Click += (s, e) => DeleteUser(user);
                        deleteButton.IsEnabled = Totals == 0; // Only enable if the book is available
                        buttonPanel.Children.Add(deleteButton);

                        // Create Modify button
                        Button modifyButton = new Button { Content = "Modify", Width = 100, Height = 40, Background = Brushes.LightGray };
                        modifyButton.Click += (s, e) => ModifyUser(user);
                        modifyButton.IsEnabled = Totals == 0; // Only enable if the book is available
                        buttonPanel.Children.Add(modifyButton);

                        UserEntryPanel.Children.Add(buttonPanel);

                        // Add the entire entry to the main BooksPanel (vertical scrolling panel)
                        UserData.Children.Add(UserEntryPanel);
                    }
                    else
                    {
                        MessageBox.Show("Unexpected line format in CSV file: " + line, "Format Error");
                    }
                }
            }
            catch (FileNotFoundException)
            {
                MessageBox.Show("Books file not found. Please check the file path.", "File Not Found", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error reading the books file: " + ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private Dictionary<char, string> genreDescriptions = new Dictionary<char, string>
        {
            { 'A', "Action and Adventure" },
            { 'B', "Biography" },
            { 'C', "Comedy" },
            { 'D', "Drama" },
            { 'E', "Children Books" },
            { 'F', "Fantasy" },
            { 'G', "Graphic Novel/Comic" },
            { 'H', "Horror" },
            { 'I', "Sci-fi" },
            { 'J', "Romance" },
            { 'K', "War" },
            { 'L', "Thriller" },
            { 'M', "Mystery" },
            { 'N', "Non-fiction" },
            { 'O', "Other" }
        };



        private int countRents(string Account)
        {
            string bookFilePath = @"C:\Users\270197547\OneDrive - UP Education\Documents\2024 programming\106.2 main assesment\MainWebsite\Library App\Library App\Books.csv";
            int rents = 0;
            try
            {
                var Booklines = File.ReadAllLines(bookFilePath);

                // Loop through each line in the CSV file (skipping the header)
                foreach (var Bookline in Booklines.Skip(1))
                {
                    var values = Bookline.Split(',');

                    if (values.Length >= 11) // Ensure all fields are present
                    {
                        string currentOwner = values[8];
                        if (currentOwner == Account)
                        {
                            rents++;
                        }
                        
                    }
                    else
                    {
                        MessageBox.Show("Unexpected line format in CSV file: " + Booklines, "Format Error");
                    }
                }

                return rents;
            }
            catch (FileNotFoundException)
            {
                MessageBox.Show("Books file not found. Please check the file path.", "File Not Found", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error reading the books file: " + ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            return rents;
        }

        private int countPreorders()
        {
            int pres = 0;
            string PreOrderPath = @"C:\Users\270197547\OneDrive - UP Education\Documents\2024 programming\106.2 main assesment\MainWebsite\Library App\Library App\PreOrderList.csv";
            return pres;

        }

        private void DeleteUser(UserClass user)
        {
            // Path to the user CSV file
            string UserfilePath = @"C:\Users\270197547\OneDrive - UP Education\Documents\2024 programming\106.2 main assesment\MainWebsite\Library App\Library App\Accounts.csv";
            var lines = File.ReadAllLines(UserfilePath).ToList();
            lines = lines.Where(line => !line.StartsWith(user.UserName + ",")).ToList(); // Remove lines matching the username
            File.WriteAllLines(UserfilePath, lines);

            // Step 3: Refresh the UI (remove the book from bookCatalogue and update BooksPanel if necessary)
            AccountList.Remove(user);
            UserData.Children.Clear();
            GetUsers();

            MessageBox.Show($"User '{user.UserName}' has been removed from the account list", "Delete Action", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        //The user has chosen to modify the book
        private void ModifyUser(UserClass user)
        {
            Window3 window3 = new Window3(CurrentUser, Admin, "MDBook", user.UserName); //MDBook means modify book, which is passed so that the code knows to only update the book in the csv
            window3.Show();
            this.Close();
        }



        private void ReturnHome_Click(object sender, RoutedEventArgs e)
        {
            //Create an instance of window3
            Window1 window1 = new Window1(CurrentUser, Admin);

            //Show window3
            window1.Show();

            //Close the main window (optional)
            this.Close();
        }

    }


}
