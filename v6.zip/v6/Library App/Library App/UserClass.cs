﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library_App
{
    public class UserClass
    {
        public UserClass(string USname, string PW, string DOB, string PNumber, string AD)
        {
            this.UserName = USname;
            this.Password = PW;
            this.DateOfBirth = DOB;
            this.PhoneNumber = PNumber;
            this.Admin = AD;
        }

        public string UserName { get; set; } //They're username
        public string Password { get; set; } //Tthey're password
        public string DateOfBirth { get; set; } //they're date of birth
        public string PhoneNumber { get; set; } //The users phone number
        public string Admin { get; set; } //Weather or not they're admin
    }
}
