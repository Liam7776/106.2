﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static System.Net.WebRequestMethods;

namespace Library_App
{
    public partial class Window3 : Window
    {
        public string CurrentUser;
        public string Admin;
        public string Change; //This variable is used to determine weather or not to add a new book 
        public string OriginalBookName;
        public Window3(string user, string admin, string change, string OGName)
        {
            InitializeComponent();
            // Clear input fields after saving
            BookNameTextBox.Clear();
            AuthorNameTextBox.Clear();
            DayTextBox.Clear();
            MonthTextBox.Clear();
            YearTextBox.Clear();
            PagesTextBox.Clear();
            DescriptionTextBox.Clear();
            ReviewTextBox.Clear();

            //Setting up variables for the user
            CurrentUser = user;
            Admin = admin;
            Change = change;
            OriginalBookName = OGName;

        }

        private void NextButton_Click(object sender, RoutedEventArgs e)
        {
            // Capture data from TextBoxes
            string bookName = BookNameTextBox.Text;
            bookName = bookName.ToLower();
            string authorName = AuthorNameTextBox.Text;
            authorName = authorName.ToLower();
            string publishedDate = $"{DayTextBox.Text}/{MonthTextBox.Text}/{YearTextBox.Text}";
            string numberOfPages = PagesTextBox.Text;
            string description = DescriptionTextBox.Text;
            string review = ReviewTextBox.Text;
            string imageCode = imageLinkTextBox.Text;


            bool Next = true;
            //Checks to see/ensure that all the data has actually been entered correctly
            if (bookName.Length == 0 || authorName.Length == 0 || numberOfPages.Length == 0 || description.Length == 0 
                || review.Length == 0 || publishedDate.Length != 10 || numberOfPages.Length == 0 || description.Length == 0)
            {
                MessageBox.Show("Please enter all the requested data correctly", "Failed" ,MessageBoxButton.OK, MessageBoxImage.Information);
                Next = false;
            }

            if (imageCode.Length == 0)
            {
                imageCode = "https://i.ibb.co/HVJ59QM/Placeholder-book-cover.jpg";
            }

            //Checks the description to ensure there are no commas
            foreach (char Character in description)
            {
                if (Character == ',')
                {
                    Next = false;
                    MessageBox.Show("Note: Please remove any commas in the story description, to avoid causing a storage error", "Failed", MessageBoxButton.OK, MessageBoxImage.Information);
                    break;
                }
               
            }

            if (Next == true)
            {
                Window4 window4 = new Window4(bookName, authorName, publishedDate, numberOfPages, description, review, imageCode, CurrentUser, Admin, Change, OriginalBookName);

                //Show window3
                window4.Show();

                //Close the main window (optional)
                this.Close();
            }

        }

        private void DescriptionTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}