﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Library_App
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    //
    public partial class Window4 : Window
    {
        //Setting up variables for the user
        public string CurrentUser;
        public string Admin;
        public string OriginalBookName;
        public string ChangeStatus;
        public string genreCode;
        public int Genres;

        private string title;
        private string author;
        private string PDate;
        private string numberOfPages;
        private string description;
        private string review;
        private string ImageLink;
        public Window4(string title, string author, string PDate, string pageNum, string Description, string score, string image, string user, string admin, string change, string OGName)
        {
            InitializeComponent();

            // Initialize the fields
            this.title = title;
            this.author = author;
            this.PDate = PDate;
            this.numberOfPages = pageNum;
            this.description = Description;
            this.review = score;
            this.ImageLink = image;

            CurrentUser = user;
            Admin = admin;
            OriginalBookName = OGName;
            ChangeStatus = change;

            if (ChangeStatus == "ADBook")
            {
                AddBookButton.Visibility = Visibility.Visible;
                ModiftButton.Visibility= Visibility.Collapsed;
            }

            else if (ChangeStatus == "MDBook")
            {
                AddBookButton.Visibility = Visibility.Collapsed;
                ModiftButton.Visibility = Visibility.Visible;
            }


        }


        //When the user chooses to go back to the preivous page
        private void Previous_Click(object sender, RoutedEventArgs e)
        {
            Window3 window3 = new Window3(CurrentUser, Admin, ChangeStatus, OriginalBookName);
            window3.Show();
            this.Close();
        }

        private void Modify_Click(object sender, RoutedEventArgs e)
        {
            Genres = 0;
            genreCode = "";

            //Checking what boxes are/aren't ticked
            if (CheckA.IsChecked == true)
            {
                genreCode = genreCode + "A";
                Genres++;
            }

            if (CheckB.IsChecked == true)
            {
                genreCode = genreCode + "B";
                Genres++;
            }

            if (CheckC.IsChecked == true)
            {
                genreCode = genreCode + "C";
                Genres++;
            }

            if (CheckD.IsChecked == true)
            {
                genreCode = genreCode + "D";
                Genres++;
            }

            if (CheckE.IsChecked == true)
            {
                genreCode = genreCode + "E";
                Genres++;
            }

            if (CheckF.IsChecked == true)
            {
                genreCode = genreCode + "F";
                Genres++;
            }

            if (CheckG.IsChecked == true)
            {
                genreCode = genreCode + "G";
                Genres++;
            }

            if (CheckH.IsChecked == true)
            {
                genreCode = genreCode + "H";
                Genres++;
            }

            if (CheckI.IsChecked == true)
            {
                genreCode = genreCode + "I";
                Genres++;
            }

            if (CheckJ.IsChecked == true)
            {
                genreCode = genreCode + "J";
                Genres++;
            }

            if (CheckK.IsChecked == true)
            {
                genreCode = genreCode + "K";
                Genres++;
            }

            if (CheckL.IsChecked == true)
            {
                genreCode = genreCode + "L";
                Genres++;
            }

            if (CheckM.IsChecked == true)
            {
                genreCode = genreCode + "M";
                Genres++;
            }

            if (CheckN.IsChecked == true)
            {
                genreCode = genreCode + "N";
                Genres++;
            }

            if (CheckO.IsChecked == true)
            {
                genreCode = genreCode + "O";
                Genres++;
            }

            //Checks how many genres have been added (Should be more than 1, but less than 6 (% is the max)
            if (Genres > 0 && Genres <= 5)
            {
                string BookfilePath = @"C:\Users\270197547\OneDrive - UP Education\Documents\2024 programming\106.2 main assesment\MainWebsite\Library App\Library App\Books.csv";
                //string BookfilePath = @"C:\2024 Yoobee work\Term 4 home\106 home\MainWebsite\Books.csv";
                string PreOrderFilePath = @"C:\Users\270197547\OneDrive - UP Education\Documents\2024 programming\106.2 main assesment\MainWebsite\Library App\Library App\PreOrderList.csv";

                //First updates the catalogue
                try
                {
                    var lines = File.ReadAllLines(BookfilePath);
                    for (int i = 1; i < lines.Length; i++)
                    {
                        var values = lines[i].Split(',');

                        // Check if this line corresponds to the current book
                        if (values[0].Trim() == OriginalBookName)
                        {
                            // Update values for current status, owner, and return date
                            values[0] = title;
                            values[1] = author;
                            values[2] = PDate;
                            values[3] = numberOfPages;
                            values[4] = description;
                            values[5] = review;
                            values[6] = genreCode;
                            values[10] = ImageLink;

                            // Update the line in the array
                            lines[i] = string.Join(",", values);
                            break;
                        }
                    }

                    // Write all lines back to the CSV file
                    File.WriteAllLines(BookfilePath, lines);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error updating CSV file: " + ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }

                //Then updates the pre-order list
                try
                {
                    var PreOrderlines = File.ReadAllLines(PreOrderFilePath);

                    // Loop through each line in the CSV file (skipping the header)
                    foreach (var line in PreOrderlines.Skip(1))
                    {
                        var values = line.Split(',');

                        if (values.Length >= 11) // Ensure all fields are present
                        {
                            if (values[0] == OriginalBookName)
                            {
                                values[0] = title;
                            }
                        }
                    }
                }
                catch (FileNotFoundException)
                {
                    MessageBox.Show("Books file not found. Please check the file path.", "File Not Found", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error reading the books file: " + ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }

                // Notify the user
                MessageBox.Show("Book details updated", "Success", MessageBoxButton.OK, MessageBoxImage.Information);

                Window1 HomePage = new Window1(CurrentUser, Admin);

                //Show window1
                HomePage.Show();

                //Close the main window (optional)
                this.Close();
            }

        }

        //When the user is ready to add a new book, the code checks what genres have been checked (if any) and then stores all the data
        private void AddToCattalogue_Click(object sender, RoutedEventArgs e)
        {
            Genres = 0;
            genreCode = "";

            //Checking what boxes are/aren't ticked
            if (CheckA.IsChecked == true)
            {
                genreCode = genreCode + "A";
                Genres ++;
            }

            if (CheckB.IsChecked == true)
            {
                genreCode = genreCode + "B";
                Genres++;
            }

            if (CheckC.IsChecked == true)
            {
                genreCode = genreCode + "C";
                Genres++;
            }

            if (CheckD.IsChecked == true)
            {
                genreCode = genreCode + "D";
                Genres++;
            }

            if (CheckE.IsChecked == true)
            {
                genreCode = genreCode + "E";
                Genres++;
            }

            if (CheckF.IsChecked == true)
            {
                genreCode = genreCode + "F";
                Genres++;
            }

            if (CheckG.IsChecked == true)
            {
                genreCode = genreCode + "G";
                Genres++;
            }

            if (CheckH.IsChecked == true)
            {
                genreCode = genreCode + "H";
                Genres++;
            }

            if (CheckI.IsChecked == true)
            {
                genreCode = genreCode + "I";
                Genres++;
            }

            if (CheckJ.IsChecked == true)
            {
                genreCode = genreCode + "J";
                Genres++;
            }

            if (CheckK.IsChecked == true)
            {
                genreCode = genreCode + "K";
                Genres++;
            }

            if (CheckL.IsChecked == true)
            {
                genreCode = genreCode + "L";
                Genres++;
            }

            if (CheckM.IsChecked == true)
            {
                genreCode = genreCode + "M";
                Genres++;
            }

            if (CheckN.IsChecked == true)
            {
                genreCode = genreCode + "N";
                Genres++;
            }

            if (CheckO.IsChecked == true)
            {
                genreCode = genreCode + "O";
                Genres++;
            }

            //Checks how many genres have been added (Should be more than 1, but less than 6 (% is the max)
            if (Genres > 0 && Genres <= 5)
            {
                string BookfilePath = @"C:\Users\270197547\OneDrive - UP Education\Documents\2024 programming\106.2 main assesment\MainWebsite\Library App\Library App\Books.csv";
                //string BookfilePath = @"C:\2024 Yoobee work\Term 4 home\106 home\MainWebsite\Books.csv";
                string PreOrderFilePath = @"C:\Users\270197547\OneDrive - UP Education\Documents\2024 programming\106.2 main assesment\MainWebsite\Library App\Library App\PreOrderList.csv";

                // Check if file exists; if not, create it and add headers
                if (!File.Exists(BookfilePath))
                {
                    using (var writer = new StreamWriter(BookfilePath, append: true))
                    {
                        writer.WriteLine("Book Name,Author Name,Published Date,Number of Pages,Description,Review, Genre code, In Stock, Current Owner, Return Date, Image code");
                    }
                }

                // Append the book details to the CSV file
                using (var writer = new StreamWriter(BookfilePath, append: true))
                {
                    writer.WriteLine($"{title},{author},{PDate},{numberOfPages},{description},{review},{genreCode},1,none,nome, {ImageLink}");
                }

                // Automatically update PreOrderList.csv with the first column (book names) from Books.csv
                UpdatePreOrderList(BookfilePath, PreOrderFilePath);

                // Notify the user
                MessageBox.Show("Book details saved successfully!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);

                Window1 HomePage = new Window1(CurrentUser, Admin);

                //Show window1
                HomePage.Show();

                //Close the main window (optional)
                this.Close();
            }

            else if (Genres == 0)
            {
                MessageBox.Show("Please select atleast 1 genre ", "Failed", MessageBoxButton.OK, MessageBoxImage.Error);
            }

            else if (Genres > 5)
            {
                MessageBox.Show("Please only select a maximum of 5 genres ", "Failed", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // Method to update PreOrderList.csv with book names from Books.csv
        /*private void UpdatePreOrderList(string bookFilePath, string preOrderFilePath)
        {
            if (File.Exists(bookFilePath))
            {
                // Extract the first column (book names) from Books.csv
                var bookNames = File.ReadLines(bookFilePath)
                                    .Skip(1) // Skip the header
                                    .Select(line => line.Split(',')[0]) // Get only the book name (first column)
                                    .ToList();

                // Ensure PreOrderList.csv exists and write book names to it
                using (var writer = new StreamWriter(preOrderFilePath, false)) // Overwrite existing content
                {
                    writer.WriteLine("Book Name"); // Header for PreOrderList.csv
                    foreach (var name in bookNames)
                    {
                        writer.WriteLine(name);
                    }
                }
            }
            else
            {
                MessageBox.Show("Books.csv file not found!", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }*/

    }
}
